MainWindow.xaml = Ms Gen UI
MainWindow.xaml.cs = Ms Gen Function


Install Visual Studio Codde at https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170

Find a Youtube Video to setup if you dont know