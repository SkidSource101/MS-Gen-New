﻿using System;
using System.IO;
using System.Text;
using System.Windows;
using Microsoft.Win32;

namespace WpfApp6
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Calculate_Click(object sender, RoutedEventArgs e)
        {
            double value1 = 3.70;
            double value2 = 7.31;
            double multiplier = 1.01;
            double target = 15.8;

            var output = new StringBuilder();
            output.AppendLine("Value 1    | Value 2");
            output.AppendLine("--------------------");

            while (value1 < target || value2 < target)
            {
                if (value1 < target) value1 *= multiplier;
                if (value2 < target) value2 *= multiplier;
                output.AppendLine($"{value1,10:F4} | {value2,10:F4}");
            }

            ConsoleOutput.Text = output.ToString();
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            ConsoleOutput.Text = string.Empty;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Text files (*.txt)|*.txt",
                Title = "Save Output",
                FileName = "Output.txt"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                File.WriteAllText(saveFileDialog.FileName, ConsoleOutput.Text);
                MessageBox.Show("File saved successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
